create schema toysgroup_antonio_vindigni;
-- creazione tabella Category;

CREATE TABLE Category (
    category_id INT PRIMARY KEY,
    category_name VARCHAR(100) 
);

-- creazione tabella Product;

CREATE TABLE Product (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100),
    price DECIMAL(10, 2),
    category_id INT,
    FOREIGN KEY (category_id) REFERENCES Category(category_id)
);

-- creazione tabella Region

CREATE TABLE Region (
    region_id INT PRIMARY KEY,
    region_name VARCHAR(100),
    city VARCHAR(100),
    country VARCHAR(100)
);

-- creazione tabella Sales

CREATE TABLE Sales (
    sale_id INT PRIMARY KEY,
    sale_date DATE,
    quantity INT,
    amount DECIMAL(10, 2),
    product_id INT,
    region_id INT,
    FOREIGN KEY (product_id) REFERENCES Product(product_id),
    FOREIGN KEY (region_id) REFERENCES Region(region_id)
    );
    
-- valori tabella Category;
    
INSERT INTO Category (category_id, category_name)
VALUES
    (1, 'Action Figures'),
    (2, 'Dolls'),
    (3, 'Board Games'),
    (4, 'Cars'),
    (5, 'Teddy Bears');
    
    -- valori tabella Product;
    
    INSERT INTO Product (product_id, product_name, price, category_id)
VALUES
    (6, 'Superhero Action Figure', 19.99, 1),
    (7, 'Barbie Doll', 14.99, 2),
    (8, 'Monopoly', 29.99, 3),
    (9, 'Ferrari', 18.99,4),
    (10, 'Trudi', 49.99,5);
    
    -- valori tabella Region;
    
    INSERT INTO Region (region_id, region_name, city, country)
VALUES
    (1, 'Lombardia', 'Milano', 'ITA'),
    (2, 'Sicilia', 'Palermo', 'ITA'),
    (3, 'Piemonte', 'Torino', 'ITA'),
    (4, 'Veneto', 'Padova', 'ITA'),
    (5, 'Campania', 'Napoli', 'ITA');
    
    -- valori tabella Sales
    
    INSERT INTO Sales (sale_id, sale_date, quantity, amount, product_id, region_id)
VALUES
    (11, '2024-01-01', 5, 99.95, 6, 1),
    (12, '2024-01-02', 3, 44.97, 7, 2),
    (13, '2024-01-03', 10, 299.90, 8, 3),
    (14, '2024-01-04', 20, 379.80, 9, 4),
    (15, '2024-01-05', 45, 2249.55, 10, 5);
    
-- 1  Verificare che i campi definiti come PK siano univoci;
-- Verifica della tabella Category
SELECT 
    category_id, COUNT(*)
FROM
    Category
GROUP BY category_id
HAVING COUNT(*) > 1;

-- Verifica della tabella Product
SELECT product_id, COUNT(*)
FROM Product
GROUP BY product_id
HAVING COUNT(*) > 1;

-- Verifica della tabella Region
SELECT region_id, COUNT(*)
FROM Region
GROUP BY region_id
HAVING COUNT(*) > 1;

-- Verifica della tabella Sales
SELECT sale_id, COUNT(*)
FROM Sales
GROUP BY sale_id
HAVING COUNT(*) > 1;

-- 2Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno;
SELECT 
    product.product_id,
    product.product_name,
    YEAR(sales.sale_date) AS anno,
    SUM(sales.amount) AS fatturato_totale
FROM 
    Product 
JOIN 
    Sales ON product.product_id = sales.product_id
GROUP BY 
    product.product_id, 
    YEAR(sales.sale_date)
ORDER BY 
    product.product_id, 
    YEAR(sales.sale_date);
    
    -- 3Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente;
    SELECT 
    YEAR(sales.sale_date) AS anno,
    region.country AS stato,
    SUM(sales.amount) AS totale_fatturato
FROM 
    Sales 
JOIN 
    Region ON sales.region_id = region.region_id
GROUP BY 
    YEAR(sales.sale_date),
    region.country
ORDER BY 
    YEAR(sales.sale_date) DESC,
    totale_fatturato DESC;
    
    -- 4qual è la categoria di articoli maggiormente richiesta dal mercato? 
    SELECT 
    category.category_name,
    SUM(sales.quantity) AS totale_venduti
FROM 
    Sales 
JOIN 
    Product  ON sales.product_id = product.product_id
JOIN 
    Category ON product.category_id = category.category_id
GROUP BY 
    category.category_name
ORDER BY 
    totale_venduti DESC
LIMIT 1;

-- 5quali sono, se ci sono, i prodotti invenduti;
SELECT 
    product.product_id,
    product.product_name
FROM 
    Product 
LEFT JOIN 
    Sales ON product.product_id = sales.product_id
WHERE 
    sales.product_id IS NULL;
    
    -- 5bis risoluzione alternativa;
    SELECT 
    product_id,
    product_name
FROM 
    Product
WHERE 
    product_id NOT IN (SELECT DISTINCT product_id FROM Sales);
    
    -- 6Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente);
     select   product.product_id,
    product.product_name,
    (
        SELECT MAX(sale_date)
        FROM Sales
        WHERE product_id = product.product_id
    ) AS data_ultima_vendita
FROM 
    Product;